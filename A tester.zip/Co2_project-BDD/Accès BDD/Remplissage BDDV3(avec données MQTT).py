#import mysql.connector

import paho.mqtt.client as mqtt

# Paramètres de connexion au broker MQTT
broker_address = "172.20.233.80"
broker_port = 1883
topic = "test_co2"


# Fonction de callback qui est appelée lorsque le client MQTT se connecte au broker
def on_connect(client, userdata, flags, rc):
    print("Connexion au broker MQTT établie avec succès")

    # Abonnement au topic
    client.subscribe(topic)


# Fonction de callback qui est appelée lorsque le client MQTT reçoit un message
def on_message(client, userdata, message):
    print("Message reçu sur le topic :", message.topic)
    print("Contenu du message :", message.payload())


# Création d'un client MQTT
client = mqtt.Client()
client.on_connect = on_connect
client.on_message = on_message


# Connexion au broker MQTT
client.connect(broker_address, broker_port)


# Boucle principale du client MQTT
client.loop_forever() 



