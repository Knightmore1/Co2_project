import paho.mqtt.client as mqtt
import json

# Callback appelée lors de la connexion au broker MQTT
def on_connect(client, userdata, flags, rc):
    print("Connecté au broker MQTT avec le code de retour : " + str(rc))
    # Abonnement au sujet "maison/capteurs"
    client.subscribe("test_co2")

# Callback appelée lorsqu'un message est reçu sur le sujet "maison/capteurs"
def on_message(client, userdata, msg):
    # Décodage du message JSON
    donnees = json.loads(msg.payload.decode())
    print("Reçu : " + str(donnees))

# Création d'un client MQTT
client = mqtt.Client()

# Configuration du callback pour la connexion au broker MQTT
client.on_connect = on_connect

# Configuration du callback pour la réception des messages MQTT
client.on_message = on_message

# Connexion au broker MQTT
client.connect("172.20.233.80", 1883, 60)

# Boucle d'écoute des messages MQTT
client.loop_forever()
