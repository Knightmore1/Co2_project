import paho.mqtt.client as mqtt
import mysql.connector

# Configuration de la connexion MQTT
mqtt_broker_address = "localhost"
mqtt_broker_port = 1883
mqtt_topic1 = "topic"
mqtt_topic2 = "topic2"

# Configuration de la connexion MySQL
mysql_host = "localhost"
mysql_user = "admin"
mysql_password = "admin"
mysql_database = "base-projet"

# Fonction de rappel pour la réception de messages MQTT
def on_message(client, userdata, message):
    topic = message.topic
    payload = message.payload.decode()
    # Connexion à la base de données MySQL et insertion des données
    try:
        cnx = mysql.connector.connect(user=mysql_user, password=mysql_password,
                                      host=mysql_host, database=mysql_database)
        cursor = cnx.cursor()
        if topic == mqtt_topic1:
            query = "INSERT INTO test (brok) VALUES (%s)"
            data = (payload,)
            print("Données du topic numéro 1 envoyées")
        elif topic == mqtt_topic2:
            query = "INSERT INTO test (toto) VALUES (%s)"
            data = (payload,)
            print("Données du topic numéro 2 envoyées")
        else:
            print("Problème lors de l'envoi")
        cursor.execute(query, data)
        cnx.commit()
    except mysql.connector.Error as err:
        print("Erreur lors de l'insertion des données : {}".format(err))
    finally:
        cursor.close()
        cnx.close()

# Configuration du client MQTT
client = mqtt.Client()
client.on_message = on_message
client.connect(mqtt_broker_address, mqtt_broker_port)
client.subscribe(mqtt_topic1)
client.subscribe(mqtt_topic2)

# Boucle principale pour la réception de messages MQTT
client.loop_forever()
