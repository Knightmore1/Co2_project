import mysql.connector

# Paramètres de connexion à la base de données
host = "localhost"
user = "admin"
password = "admin"
database = "base-projet"

# Connexion à la base de données
try:
    cnx = mysql.connector.connect(host=host, user=user, password=password, database=database)
    print("Connexion à la base de données réussie")
    

except mysql.connector.Error as err:
    print("Erreur de connexion à la base de données : {}".format(err))

finally:
    # Fermeture de la connexion
    if 'cnx' in locals() and cnx.is_connected():
        cnx.close()
        print("Connexion à la base de données fermée")
